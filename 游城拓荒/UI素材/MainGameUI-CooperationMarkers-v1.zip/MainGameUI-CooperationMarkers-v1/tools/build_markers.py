#!/usr/bin/env python3
"""Build exact-colour cooperation markers as SVG and transparent PNG.

Requires Python 3, Pillow, and Inkscape available on PATH.
Run: python tools/build_markers.py
"""
from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path
from xml.sax.saxutils import escape

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "04-markers"
SIZES = (32, 64, 128)
COLORS = (
    {"key": "G", "name": "Green", "bit": 1, "hex": "#5FD200"},
    {"key": "Y", "name": "Yellow", "bit": 2, "hex": "#FFBF00"},
    {"key": "B", "name": "Blue", "bit": 4, "hex": "#006CFF"},
    {"key": "R", "name": "Red", "bit": 8, "hex": "#EC0000"},
)
METAL = {"body": "#716E65", "edge": "#BBB7AB", "shadow": "#292E2B", "empty": "#171D1A"}


def svg(body: str, width: int = 128, height: int = 128) -> str:
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">{body}</svg>\n'


def luminance(h: str) -> float:
    values = [int(h[i:i+2], 16) / 255 for i in (1, 3, 5)]
    linear = [v / 12.92 if v <= .04045 else ((v + .055) / 1.055) ** 2.4 for v in values]
    return sum(a*b for a, b in zip(linear, (.2126, .7152, .0722)))


def text_advice(h: str) -> dict:
    lum = luminance(h)
    black, white = (lum + .05) / .05, 1.05 / (lum + .05)
    best = "#000000" if black >= white else "#FFFFFF"
    return {"recommended_hex": best, "contrast_black": round(black, 3), "contrast_white": round(white, 3),
            "recommended_contrast": round(max(black, white), 3), "small_text_wcag_aa": max(black, white) >= 4.5}


def marker_body(members: list[dict]) -> str:
    # All colour regions are exact solid fills. Each shares the same 96x96 square.
    frame = (
        f'<path d="M18 10H110L118 18V110L110 118H18L10 110V18Z" fill="{METAL["body"]}" stroke="{METAL["edge"]}" stroke-width="2"/>'
        '<path d="M18 12H110L116 18M12 18V110" fill="none" stroke="#D8D4C8" stroke-width="1"/>'
        '<path d="M116 18V110L110 116H18" fill="none" stroke="#393E39" stroke-width="2"/>'
        f'<rect x="14" y="14" width="100" height="100" fill="{METAL["shadow"]}"/>'
    )
    c = [x["hex"] for x in members]
    if not c:
        return frame + f'<rect x="16" y="16" width="96" height="96" fill="{METAL["empty"]}"/>'
    if len(c) == 1:
        return frame + f'<rect x="16" y="16" width="96" height="96" fill="{c[0]}"/>'
    if len(c) == 2:
        # Two exact half-square triangles, sharing a top-right to bottom-left diagonal.
        return frame + f'<rect x="16" y="16" width="96" height="96" fill="{c[1]}"/><path d="M16 16H112L16 112Z" fill="{c[0]}"/>'
    if len(c) == 3:
        return frame + ''.join(f'<rect x="{16+32*i}" y="16" width="32" height="96" fill="{h}"/>' for i, h in enumerate(c))
    return frame + ''.join(f'<rect x="{16+48*(i%2)}" y="{16+48*(i//2)}" width="48" height="48" fill="{h}"/>' for i, h in enumerate(c))


def overlay_bodies() -> dict[str, str]:
    return {
        "hover": '<path d="M17 6H111L122 17V111L111 122H17L6 111V17Z" fill="none" stroke="#F5F1E4" stroke-width="2" opacity="0.8"/>',
        "selected": '<path d="M16 3H112L125 16V112L112 125H16L3 112V16Z" fill="none" stroke="#FFFFFF" stroke-width="3"/><path d="M4 26V16L16 4H26M102 124H112L124 112V102" fill="none" stroke="#FFFFFF" stroke-width="5"/><path d="M109 2H126V13H109Z" fill="#FFFFFF"/><path d="M113 7L116 10L122 4" fill="none" stroke="#202722" stroke-width="2" stroke-linecap="square" stroke-linejoin="miter"/>',
        "focus": '<path d="M17 3H111L125 17V111L111 125H17L3 111V17Z" fill="none" stroke="#CFE1E4" stroke-width="2" stroke-dasharray="5 4"/>',
    }


def export_art(stem: str, body: str) -> dict:
    src = OUT / f"{stem}.svg"
    src.write_text(svg(body), encoding="utf-8")
    pngs = {}
    for size in SIZES:
        target = OUT / f"{stem}-{size}.png"
        subprocess.run(["inkscape", str(src), f"--export-filename={target}", f"--export-width={size}", f"--export-height={size}"],
                       check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        pngs[str(size)] = target.name
    return {"svg": src.name, "png": pngs}


def geometry(members: list[dict]) -> dict:
    n = len(members)
    if n == 0:
        return {"kind": "empty", "region": [16, 16, 96, 96], "fill": METAL["empty"]}
    if n == 1:
        return {"kind": "solid", "region": [16, 16, 96, 96], "order": [members[0]["key"]], "area_fraction": [1]}
    if n == 2:
        return {"kind": "diagonal-halves", "diagonal": [[112, 16], [16, 112]], "order": [m["key"] for m in members],
                "positions": ["upper-left-triangle", "lower-right-triangle"], "area_fraction": [.5, .5]}
    if n == 3:
        return {"kind": "vertical-thirds", "region": [16, 16, 96, 96], "order": [m["key"] for m in members],
                "positions": ["left", "middle", "right"], "area_fraction": [1/3, 1/3, 1/3]}
    return {"kind": "quadrants", "region": [16, 16, 96, 96], "order": [m["key"] for m in members],
            "positions": ["top-left", "top-right", "bottom-left", "bottom-right"], "area_fraction": [.25]*4}


def gallery(manifest: dict) -> None:
    width, height = 1100, 890
    body = '<rect width="1100" height="890" fill="#252A27"/>'
    body += '<g font-family="sans-serif" fill="#F0EDE3"><text x="28" y="40" font-size="24">COOPERATION MARKERS / G=1 Y=2 B=4 R=8</text><text x="28" y="67" font-size="14" fill="#BFBEB4">Exact solid colours / square content / stable GYBR order / transparent outside</text></g>'
    for i, entry in enumerate(manifest["markers"]):
        col, row = i % 8, i // 8
        x, y = 27 + col*134, 91 + row*193
        members = [c for c in COLORS if entry["mask"] & c["bit"]]
        body += f'<g transform="translate({x} {y})">{marker_body(members)}</g>'
        label = entry["id"].split('-')[1].upper() + '  ' + (''.join(m['key'] for m in members) or 'EMPTY')
        body += f'<text x="{x+64}" y="{y+151}" text-anchor="middle" font-size="15" font-family="sans-serif" fill="#E7E4D9">{escape(label)}</text>'
    body += '<text x="28" y="496" font-size="20" font-family="sans-serif" fill="#F0EDE3">STATE OVERLAYS / shown over the four-colour marker</text>'
    for i, (name, overlay) in enumerate(overlay_bodies().items()):
        x, y = 30 + i*181, 520
        body += f'<g transform="translate({x} {y})">{marker_body(list(COLORS))}{overlay}</g>'
        body += f'<text x="{x+64}" y="{y+151}" text-anchor="middle" font-size="15" font-family="sans-serif" fill="#E7E4D9">{name.upper()}</text>'
    body += '<text x="595" y="496" font-size="20" font-family="sans-serif" fill="#F0EDE3">DIGIT BACKPLATES</text>'
    for i, c in enumerate(COLORS):
        x, y = 594+i*122, 520
        body += f'<g transform="translate({x} {y}) scale(0.86)">{marker_body([c])}</g>'
        textcol = text_advice(c["hex"])["recommended_hex"]
        body += f'<text x="{x+55}" y="{y+67}" text-anchor="middle" font-size="39" font-family="sans-serif" font-weight="bold" fill="{textcol}">8</text>'
        body += f'<text x="{x+55}" y="{y+148}" text-anchor="middle" font-size="13" font-family="monospace" fill="#E7E4D9">{c["hex"]}</text>'
    body += '<g font-family="sans-serif" fill="#C9C8BE" font-size="16"><text x="28" y="730">GEOMETRY</text><text x="28" y="758">1 colour: solid  /  2 colours: diagonal halves  /  3 colours: vertical thirds  /  4 colours: quadrants</text><text x="28" y="795">PNG SIZES: 32 / 64 / 128 px  ·  SVG VIEWBOX: 128 × 128  ·  COLOUR SQUARE: x16 y16 w96 h96</text><text x="28" y="825">Numbers appear only in this preview; production marker files contain no text.</text><text x="28" y="853">Black text reaches 4.5:1 on all four exact fills; a neutral badge can improve mixed-colour legibility.</text></g>'
    src = OUT / 'gallery.svg'
    src.write_text(svg(body, width, height), encoding='utf-8')
    subprocess.run(['inkscape', str(src), f'--export-filename={OUT / "gallery.png"}'], check=True,
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def sample_points(n: int) -> list[tuple[int, int]]:
    return {0: [(64,64)], 1:[(64,64)], 2:[(40,40),(88,88)], 3:[(32,64),(64,64),(96,64)],
            4:[(40,40),(88,40),(40,88),(88,88)]}[n]


def rgb(h: str) -> tuple[int,int,int]:
    return tuple(int(h[i:i+2],16) for i in (1,3,5))


def validate(manifest: dict) -> dict:
    markers = manifest['markers']
    assert [e['mask'] for e in markers] == list(range(16))
    assert len({tuple(e['colors']) for e in markers}) == 16
    checked = 0
    for entry in markers + manifest['digit_backplates']:
        colors = entry['colors'] or [METAL['empty']]
        count = len(entry['colors'])
        for size, name in entry['paths']['png'].items():
            size = int(size)
            im = Image.open(OUT/name)
            assert im.mode == 'RGBA', (name, im.mode)
            assert im.size == (size,size)
            for xy in [(0,0),(size-1,0),(0,size-1),(size-1,size-1)]:
                assert im.getpixel(xy)[3] == 0, (name,xy,'corner not transparent')
            for point, color in zip(sample_points(count), colors):
                p = (round(point[0]*size/128),round(point[1]*size/128))
                assert im.getpixel(p) == (*rgb(color),255), (name,p,im.getpixel(p),color)
            checked += 1
    for entry in manifest['state_overlays']:
        for size, name in entry['paths']['png'].items():
            size = int(size)
            im = Image.open(OUT/name)
            assert im.mode == 'RGBA' and im.size == (size,size)
            # States never cover the central colour square.
            core = im.getchannel('A').crop((size//8,size//8,7*size//8,7*size//8))
            assert core.getextrema() == (0,0), (name,'state invades colour region')
            checked += 1
    return {'status':'passed', 'combinations':16, 'nonempty_combinations':15, 'png_files_checked':checked,
            'png_sizes':list(SIZES), 'rgba_transparency':True, 'exact_interior_rgb':True,
            'state_overlays_preserve_colour_square':True}


def main() -> None:
    if not shutil.which('inkscape'):
        raise SystemExit('Inkscape is required to render the native SVG files.')
    OUT.mkdir(parents=True,exist_ok=True)
    manifest = {
        'version':'1.0.0', 'coordinate_system':{'svg_viewbox':[0,0,128,128], 'color_square':[16,16,96,96],
            'png_sizes':list(SIZES), 'transparent_outer_corners':True},
        'bit_order':'GYBR', 'palette':[{**c,'text':text_advice(c['hex'])} for c in COLORS],
        'frame_palette':METAL, 'markers':[], 'state_overlays':[], 'digit_backplates':[],
        'text_guidance':{
            'digit_anchor_svg':[64,64], 'digit_safe_box_svg':[34,34,60,60],
            'single_colour':'Use the recommended pure black or pure white foreground for that colour; recommendations apply to exact fully opaque fills.',
            'multi_colour':'Black text reaches at least 4.5:1 on all four exact palette fills. A neutral opaque text badge can improve legibility across patterned colour boundaries.',
            'multi_colour_badge':{'background':'#171D1A','foreground':'#FFFFFF'},
            'production_art_contains_text':False,
        },
        'integration':{'order':['marker','state overlay','optional number text'],
            'scaling':'Keep a square aspect ratio. Place overlays at exactly the same origin and dimensions as their marker.',
            'two_colour_layout':'One square split diagonally; never two separate tiles.',
            'colour_values':'RGB interior values are exact; antialiased boundary pixels may be blended.'},
    }
    for mask in range(16):
        members = [c for c in COLORS if mask & c['bit']]
        stem = f'cooperation-{mask:02x}'
        manifest['markers'].append({'id':stem,'mask':mask,'mask_hex':f'{mask:02x}',
            'members':[c['key'] for c in members], 'colors':[c['hex'] for c in members],
            'geometry':geometry(members), 'paths':export_art(stem,marker_body(members))})
    for name,body in overlay_bodies().items():
        manifest['state_overlays'].append({'id':name,'paths':export_art(f'overlay-{name}',body),
            'preserves_color_square':True,'transparent_interior':True})
    for c in COLORS:
        stem = f'digit-base-{c["name"].lower()}'
        manifest['digit_backplates'].append({'id':stem,'mask':c['bit'],'members':[c['key']],
            'colors':[c['hex']],'geometry':geometry([c]),'text':text_advice(c['hex']),
            'paths':export_art(stem,marker_body([c]))})
    manifest['validation'] = validate(manifest)
    gallery(manifest)
    manifest['gallery'] = {'svg':'gallery.svg','png':'gallery.png'}
    (OUT/'markers.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'output':str(OUT),'svg_assets':23,'png_assets':69,'gallery_files':2,
                      'manifest_files':1,'validation':manifest['validation']},ensure_ascii=False))


if __name__ == '__main__':
    main()
