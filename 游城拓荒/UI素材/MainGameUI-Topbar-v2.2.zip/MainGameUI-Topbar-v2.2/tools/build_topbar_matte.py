#!/usr/bin/env python3
"""Compose reference-aligned header layers from unchanged generated art using SVG.

No raster retouching: Inkscape renders clipped image references and layer masks.
"""
from pathlib import Path
import json, subprocess
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
SOURCE = '05-textures/art/topbar-matte-source.png'
BACKGROUND = '05-textures/art/topbar-matte-background.png'
ASSETS = []

def rect(x,y,w,h): return f'M{x} {y}h{w}v{h}h{-w}Z'
def crop(sx,sy,sw,sh,x,y,w,h):
    return f'<image xlink:href="../{SOURCE}" width="2172" height="724" transform="matrix({w/sw} 0 0 {h/sh} {x-sx*w/sw} {y-sy*h/sh})"/>'
def save(ident,w,h,body,clip=None,border=None,role='background',position=None):
    defs=f'<clipPath id="layer" clipPathUnits="userSpaceOnUse"><path d="{clip}" fill-rule="evenodd" clip-rule="evenodd"/></clipPath>' if clip else ''
    if clip: body=f'<g clip-path="url(#layer)">{body}</g>'
    svg=ROOT/'01-topbar'/f'{ident}.svg'
    svg.write_text(f'<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="{w}" height="{h}" viewBox="0 0 {w} {h}"><defs>{defs}</defs>{body}</svg>\n')
    subprocess.run(['inkscape',str(svg),'--export-type=png','--export-area-page','--export-background-opacity=0',f'--export-filename={svg.with_suffix(".png")}'],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
    with Image.open(svg.with_suffix('.png')) as im:
        assert im.size==(w,h) and im.mode=='RGBA'
        center=im.getpixel((w//2,h//2))[3]
    b=border or dict(left=0,top=0,right=0,bottom=0)
    ASSETS.append(dict(id=ident,svg=f'01-topbar/{ident}.svg',png=f'01-topbar/{ident}.png',sourceSize=dict(width=w,height=h),border=b,role=role,material=SOURCE,hasText=False,centerAlpha=center,recommendedDisplayRect=position,resize='uniform; topbar fill may stretch horizontally; preserve grouped control proportions',representation='Native SVG clipping of unchanged generated raster source; not editable vector illustration'))

def paired(base,w,h,body,inner,border,position,outer=None):
    outer=outer or rect(0,0,w,h)
    save(base+'-fill',w,h,body,inner,border,'independent-fill',position)
    save(base+'-frame',w,h,body,outer+' '+inner,border,'transparent-frame',position)

def main():
    # Broad, quiet center material. This opaque full-bleed layer covers old screen chrome.
    backing=crop(0,324,2172,77,0,0,1920,68).replace(SOURCE,BACKGROUND)
    save('topbar-fill',1920,68,'<rect width="1920" height="68" fill="#292722"/>'+backing,position=[0,0,1920,68])
    ASSETS[-1]['material']=BACKGROUND
    ASSETS[-1]['sourceCrop']=[0,324,2172,77]
    save('topbar-frame',1920,68,crop(0,398,2172,9,0,64,1920,4),rect(0,64,1920,4),dict(left=0,top=0,right=0,bottom=4),'bottom-separation-edge',[0,0,1920,68])
    # Reference's broad diagonal title shoulder; no extra bolts or high-gloss rims.
    title=crop(17,316,517,79,0,0,474,64)
    title_outer='M0 0H422L474 47V64H0Z'
    title_inner='M3 3H404L471 49V61H3Z'
    title_b=dict(left=8,top=0,right=76,bottom=0)
    paired('title-plaque',474,64,title,title_inner,title_b,[16,0,474,64],title_outer)
    save('title-plaque',474,64,title,title_outer,title_b,'optional-combined-title-decoration',[16,0,474,64])
    flag=crop(1220,321,243,70,0,0,204,49)
    flag_outer='M0 0H184L204 24.5L184 49H0L19 24.5Z'
    flag_inner='M3 2H182.5L201.5 24.5L182.5 47H3L21 24.5Z'
    paired('turn-ribbon',204,49,flag,flag_inner,dict(left=24,top=0,right=24,bottom=0),[1075,7,204,49],flag_outer)
    group=''
    for sx,sw,dx,dw in [(1622,283,0,242),(1905,175,242,167),(2080,78,409,65)]:
        group+=f'<defs><clipPath id="section{dx}" clipPathUnits="userSpaceOnUse"><rect x="{dx}" y="0" width="{dw}" height="59"/></clipPath></defs><g clip-path="url(#section{dx})">'+crop(sx,316,sw,79,dx,0,dw,59)+'</g>'
    # Three interior apertures keep both separators in the independent frame layer.
    group_outer='M54 0H474V59H0V45Z'
    group_inner='M55 3H239V56H3V46Z '+rect(244,3,162,53)+' '+rect(412,3,59,53)
    paired('right-cluster',474,59,group,group_inner,dict(left=62,top=0,right=66,bottom=0),[1436,3,474,59],group_outer)
    meta=dict(version='2.2.0',assets=ASSETS,source=SOURCE,sourceSize=[2172,724],sourceHeaderBand=[0,306,2172,101],reference='Approved main-screen concept exec-333ae77c-4116-4a55-99a2-d987fa429236.png; layout and silhouette reference, not a pixel-identical extraction',layerOrder=['topbar-fill','topbar-frame','title-plaque-fill + title-plaque-frame','turn-ribbon-fill + turn-ribbon-frame','right-cluster-fill + right-cluster-frame','runtime labels and icons','transparent interaction hit areas'],rightCluster={'redZone':[0,0,242,59],'collapse':[242,0,167,59],'settings':[409,0,65,59],'resize':'Keep whole cluster uniform to preserve three control areas; do not nine-slice it as one control.'},rules={'redZoneOpenRoundByPlayerCount':{'2':6,'3':5,'4':4},'redRoutesAlwaysUsable':True},deprecatedAssets=['red-zone-ribbon-fill','red-zone-ribbon-frame'],validation={'allLayersRendered':True,'allSizesChecked':True,'textBakedIntoTextures':False,'sourcePngUnchanged':True})
    (ROOT/'01-topbar/topbar-v22.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
    # Keep established IDs synchronized for engines already importing the catalog.
    for name in ['chrome.json','textures.json','01-topbar/title-plaque.json','01-topbar/status-ribbons.json']:
        p=ROOT/name
        if not p.exists(): continue
        data=json.loads(p.read_text()); lookup={a['id']:a for a in ASSETS}
        data['assets']=[lookup.get(a['id'],a) for a in data['assets']]
        data['version']='2.2.0'
        if name.endswith('title-plaque.json'):
            data['note']='Use the new matte layers at 474 x 64. Combined title is optional; do not overlay with separate layers.'
        if name.endswith('status-ribbons.json'):
            data['deprecated']=['red-zone-ribbon-fill','red-zone-ribbon-frame']
            data['sourceSliceNotes']='v2.2 turn flag has source size 204 x 49 and horizontal caps 24. Red flag assets remain only for compatibility; use right-cluster for red-zone information.'
            data.pop('validation',None)
        p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
    print(f'Exported {len(ASSETS)} matte topbar layers and synchronized metadata.')

if __name__=='__main__': main()
